package Products;

public class Meats extends Edible{
    public Meats(String nameofpro, String description,String brand, long price, int amount, int discount) {
        super(nameofpro, description, brand, price, amount, discount);
    }
}
