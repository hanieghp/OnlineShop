package Products;

public class DairyProducts extends Edible{
    public DairyProducts(String nameofpro, String description,String brand, long price, int amount, int discount) {
        super(nameofpro, description,brand, price, amount, discount);
    }
}

