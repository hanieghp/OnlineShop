package Products;

public class Junkfood extends Edible{
    public Junkfood(String nameofpro, String description, String brand, long price, int amount, int discount) {
        super(nameofpro, description, brand, price, amount, discount);
    }
}
