package Products;

import java.util.ArrayList;

public abstract class User {
    protected String username;
    protected String password;
    ArrayList<Product> boughtpro = new ArrayList<>();


}
